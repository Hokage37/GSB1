<div class="info">
<ul><li>
<?php 
      echo $message;
?>
</li></ul>
</div>