﻿  <div id="contenu">
      <h2>Bienvenue sur l'intranet GSB</h2>
  </div>
